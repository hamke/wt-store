<?php

$filename = "https://hellotblog.files.wordpress.com/2018/07/11.pdf";

echo $filename;
